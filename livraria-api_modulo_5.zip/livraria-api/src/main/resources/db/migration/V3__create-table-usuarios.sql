CREATE TABLE usuarios (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  nome varchar(100) NOT NULL,
  login varchar(100) NOT NULL,  
  senha varchar(100) NOT NULL,
  PRIMARY KEY (id)
  ) 
