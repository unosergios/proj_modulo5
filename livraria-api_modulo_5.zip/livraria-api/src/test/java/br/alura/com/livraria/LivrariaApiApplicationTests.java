package br.alura.com.livraria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivrariaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
